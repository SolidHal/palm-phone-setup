#!/usr/bin/env sh

mount -o rw,remount /system
mount -o rw,remount /vendor

## OBJECTIVE: 1 ##
echo "Removing user installs..."
pm uninstall -k --user 0 'com.verizon.cloudsetupwizard'
pm uninstall -k --user 0 'com.verizon.mips.services'
pm uninstall -k --user 0 'com.vzw.hss.myverizon'
pm uninstall -k --user 0 'com.jrd.verizonuriintentservice'
pm uninstall -k --user 0 'com.verizon.messaging.vzmsgs'
pm uninstall -k --user 0 'com.verizon.llkagent'
pm uninstall -k --user 0 'com.vzw.apnlib'
pm uninstall -k --user 0 'com.tcl.vzwintents'
pm uninstall -k --user 0 'com.tct.vzwwifioffload'
pm uninstall -k --user 0 'com.vzw.ecid'
pm uninstall -k --user 0 'com.vzw.easvalidation'
pm uninstall -k --user 0 'com.customermobile.preload.vzw'
pm uninstall -k --user 0 'com.vcast.mediamanager'
pm uninstall -k --user 0 'com.ts.setupwizard.overlay.overlay'
pm uninstall -k --user 0 'com.jrdcom.Elabel.overlay'
pm uninstall -k --user 0 'com.android.dreams.phototable.overlay'
pm uninstall -k --user 0 'com.android.email.partnerprovider.overlay'
pm uninstall -k --user 0 'com.telecomsys.directedsms.android.SCG'
pm uninstall -k --user 0 'com.google.android.marvin.talkback'
pm uninstall -k --user 0 'com.android.wallpaper.livepicker.overlay'
pm uninstall -k --user 0 'com.google.android.ext.services'

echo "Removing system bloatware..."
cd /system/app
## WARN: no remove (will brick): GoogleExtShared SecureExtAuthService
rm -rf MMITest talkback SecureSampleAuthService EasValidation SampleExtAuthService SampleAuthenticatorService LiveWallpapersPicker AutoRegistration EmailPartnerProvider StatsPollManager FidoCryptoService OneTouchFeedback CloudSetupWizardOverlay BasicDreams Gmail2 SuperEngineerMode CompanionDeviceManager GmsSampleIntegration PartnerBookmarksProvider GoogleContactsSyncAdapter PhotoTable BluetoothMidiService Photos TestMode remotesimlockservice CalendarGoogle GooglePrintRecommendationService VerizonUrintentService verizon-wifi-offload Videos vzwintents YGPS YouTube Music2 Maps EasterEgg Drive Duo 

cd /system/priv-app
rm -rf AutoKillService Fota ConfigUpdater GoogleBackupTransport GoogleServicesFramework StatementService VerizonNameID GmsCore TagGoogle WiFiActivation com.customermobile.preload.vzw Elabel GoogleFeedback GoogleOneTimeInitializer GooglePartnerSetup Phonesky SetupWizardOverlay SetupWizard VZWAPNLib Velvet verizon-llk-agent

cd /vendor/app
rm -rf ChromeCustomizations VzwDMClient unremoveable/Fleksy-9.7.6-palm-2860-armeabi-v7a-palmPlayStoreRelease.apk

cd /vendor/priv-app
rm -rf MVM_vzw_app-release-phone-13.1.1-278.apk VZMessages-mobile-6.7.12-94-market-release-signed.apk Verizon_LocationAgent_vzw_v0.0.3.120_Production_NoDebug_release_signed.apk client-17.6.14-prod-phone-release.apk

rm -rf /storage/self/primary/Android/data/com.google.* ## leftover data folders
rm -rf /data/app/com.android.vending*  ## remove Play after it's updated itself
mv /data/app/rkr.simplekeyboard.inputmethod-* /system/app  ## required in case user forces pin on boot
mv /vendor/bin/mmid /vendor/bin/mmid.bak  ## couldn't find anything on the net about this, and it has lots of wakeups & logcat writing.

## OBJECTIVE: 2 ##
echo "Fixing APN list..."
cp -F /sdcard/apns-conf.xml /vendor/etc
chmod 755 /vendor/etc/apns-conf.xml

## OBJECTIVE: 3 ##
echo "Removing Verizon traces..."
cd /vendor
cp build.prop build.prop.old
grep -v 'ro.product.vzw=true' build.prop.old > build.prop
rm JRD_custres/media/bootanimation.zip

## OBJECTIVE: 4 ##
echo "Removing Unsold-product-on-shelf battery decay limit..."
cd /system
cp build.prop build.prop.old
grep -v 'ro.cutoff_voltage_mv=3400' build.prop.old > build.prop

## OBJECTIVE: 5 ##
echo "Removing adb debugging nag"
cd /system
grep -qxF 'persist.adb.notify=0' build.prop || echo 'persist.adb.notify=0' >> build.prop

echo "Done! - rebooting."

## end
reboot

