#!/usr/bin/env sh

echo "We're about to install some APKs. If you have ones you'd like to install stick them into apks/myapps now."

read -n 1 -p Ready?;

## required
adb push push/apns-conf.xml /sdcard/

## apks
for file in apks/required/*.apk; do adb install $file; done
for file in apks/optional/*.apk; do adb install $file; done
for file in apks/myapps/*.apk; do adb install $file; done

## main script
adb push push/palm.sh /sdcard/

echo "OK, some essential apps have been installed. If you see errors above exit now, permit debugging and re-run."
echo "Do these next steps before continuing."
echo ""
echo "1. Ensure the device is connected to WIFI then run MagiskManager and click install then \"Direct Install\". "
echo "   Do this even if it says already installed. Click Reboot. Re-run MagiskManager and allow it to do the extra setup screen if asked."
echo "2. Go to Settings -> System -> Languages & Input -> Virtual Keyboard -> Manage Keyboards"
echo "   Enable \"Simple Keyboard\". Ignore the warnings, we'll make it a system keyboard in a bit."

read -n 1 -p Ready?;
echo ""
echo "Copy the following: cd /sdcard && su - -c \"sh palm.sh\""
echo "Don't forget after the next step to check the Palm Screen for a 'Superuser Grant' alert."
echo "Now, run 'adb shell', paste and hit enter."

